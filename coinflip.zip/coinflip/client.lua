RegisterCommand('coinflip', function(source, args, rawCommand)
    
    -- txt
    ShowNotification('Münze wird geworfen...')
    --warten
    Citizen.Wait(3000)
    --kopf/zahl

    local randomNumber = math.random(1, 100)
    print(randomNumber)

    if randomNumber <= 50 then 
        ShowNotification('Die Münnze zeigt ~p~Kopf')
    else 
        ShowNotification('Die Münze zeigt ~p~Zahl')
    end
end)

-------------item noch registrieren und ergebnis für spieler im umkreis anzeigen

function ShowNotification(text)
    SetNotificationTextEntry('STRING')
    AddTextComponentString(text)
    DrawNotification(false, true)
end 